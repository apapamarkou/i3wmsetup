# archscripts
Post-Install Scripts for Arch users
